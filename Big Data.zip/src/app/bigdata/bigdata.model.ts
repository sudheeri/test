export class Details{
    columns:string;
	minlengths:string;
	maxlengths:string;
	
}
 
